import { Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { CRUDServicesService } from './crudservices.service';
import { registration } from './registration.model';
import { Employee } from './shared/employee';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  selected = 'option2';
  constructor(private formBuilder: FormBuilder, public crudservice: CRUDServicesService) { }
ngOnInit(){
  this.crudservice.getEmployee().subscribe(data=>{
    this.crudservice.listofemployee=data;
  })
}
  profileForm = new FormGroup({
    userName: new FormControl("", [Validators.required, Validators.pattern("^([a-zA-Z *% '.,-]+(^.)?[\s]*)$")]),
    emailId: new FormControl("", [Validators.required, Validators.pattern("")]),
    address: new FormControl("", [Validators.required, Validators.pattern("^[\sa-zA-Z0-9.s',#/@ -/&]+$")]),
    gender: new FormControl("", [Validators.required]),
    city: new FormControl("", [Validators.required]),
    state: new FormControl("", [Validators.required,Validators.pattern("^[a-zA-Z-.'\s]*$")]),
    zipcode: new FormControl("", [Validators.required]),
   
  })

  saveForm() {
    console.log('Form data is ', this.profileForm.value);
  }
  get f() {
    return this.profileForm.controls;
  }

  postMemberDetails() {

  }
  editEmployee(employeeid:Employee) {
    console.log('employeeid')
this.crudservice.employeeData=employeeid;
  }
  deleteEmployee(id:number){
    if(confirm("really u want to delete")){
      this.crudservice.deleteEmployee(id).subscribe(data=>{
        console.log('record deleted');
        this.crudservice.getEmployee().subscribe(data=>{
          this.crudservice.listofemployee=data;
        });
      },
      err=>{
        console.log("record not deleted ");
      });
    }
  }
  // getAllMember(){
   
  // }
  getEmployee(data: Employee): void {
    this.crudservice.getEmployee()
  }

}
