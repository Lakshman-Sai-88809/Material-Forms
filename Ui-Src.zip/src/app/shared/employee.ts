export class Employee {
    id:number=0;
    userName: string;
    emailId: string;
    address: string;
    gender: string='Male';
    city: string;
    state:string;
    zipcode: number;
}

