import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { map } from 'rxjs/operators'
import { registration } from './registration.model';
import { Employee } from './shared/employee';
import { Observable } from 'rxjs';



@Injectable({
  providedIn: 'root'
})
export class CRUDServicesService {

  constructor(private http: HttpClient) { }
  employeeurl: string = 'https://localhost:7276/api/tmpTableInfo';
  listofemployee: Employee[] = [];//for getting employee
  employeeData=new Employee();
  getEmployee(): Observable<Employee[]> {
    return this.http.get<Employee[]>(this.employeeurl);
  }
  saveEmployee(){
    return this.http.post(this.employeeurl,this.employeeData)
  }
  updateEmployee(){
    return this.http.put(`${this.employeeurl}/${this.employeeData.id}`,this.employeeData)
  }
  deleteEmployee(id:number){
    return this.http.delete(`${this.employeeurl}/${id}`)
  }
}


