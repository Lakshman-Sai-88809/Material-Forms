﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using register.Model;
using register.Service;

namespace register.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RegisterController : ControllerBase
    {
        private readonly IRegisterService _RegisterService;
        public RegisterController(IRegisterService registerService)
        {
            _RegisterService = registerService;
        }


        [HttpGet("getRegistersList")]
        public async Task<List<Register>> GetProductListAsync(int registerId)
        {
            try
            {
                return await _RegisterService.GetRegistersAsync(registerId);
            }
            catch
            {
                throw;
            }
        }

        [HttpPost("addregister")]
        public async Task<IActionResult> AddProductAsync(Register register)
        {
            if (register == null)
            {
                return BadRequest();
            }

            try
            {
                var response = await _RegisterService.AddProductAsync(register);

                return Ok(response);
            }
            catch
            {
                throw;
            }
        }

        [HttpDelete]
        public async Task<IActionResult> DeleteRegisterasync(int registerId)
        {
            var response = await _RegisterService.Delete(registerId);
            return Ok(response);
        }
    }
}





    






