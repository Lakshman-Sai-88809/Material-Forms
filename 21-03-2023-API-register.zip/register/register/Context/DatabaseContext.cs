﻿using Microsoft.EntityFrameworkCore;
using register.Model;

namespace register.Context
{
    public class DatabaseContext : DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder options)
        {
            var connectionString = string.Format(@"Data Source=10.74.11.205;Initial Catalog=SmartApp_Test;User ID=CARELynx;Password=CAREington;TrustServerCertificate=True");
            options.UseSqlServer(connectionString);
        }

        public DbSet<Register>? Register { get; set; }
    }
}
