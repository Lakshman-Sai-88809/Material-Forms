﻿using register.Model;

namespace register.Service
{
    public interface IRegisterService
    {
        Task<List<Register>> GetRegistersAsync(int registerId);

        Task<int> Delete(int registerId);

        Task<int> AddProductAsync(Register register);
    }
}
