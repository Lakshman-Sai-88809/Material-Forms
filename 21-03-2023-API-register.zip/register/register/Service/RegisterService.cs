﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using register.Context;
using register.Model;
using System.Data;

namespace register.Service
{
    public class RegisterService : IRegisterService
    {
        DatabaseContext _dbContext = null;
        
        public RegisterService(DatabaseContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<int> Delete(int registerId)
        {
            var parameter = new List<SqlParameter>();
            parameter.Add(new SqlParameter("@ID", registerId));

            var result = await Task.Run(() => _dbContext.Database
           .ExecuteSqlRawAsync(@"exec DeleteRegister @ID", parameter.ToArray()));
            return result;
        }

        public async Task<List<Register>> GetRegistersAsync(int registerId)
        {
            var parameter = new List<SqlParameter>();
            parameter.Add(new SqlParameter("@ID", registerId));

            return await _dbContext.Register!.FromSqlRaw<Register>($"GetRegisters {registerId}").ToListAsync();
        }

        public async Task<int> AddProductAsync(Register register)
        {
            var parameter = new List<SqlParameter>();
            parameter.Add(new SqlParameter("@ID", register.Id));
            parameter.Add(new SqlParameter("@Name", register.name));
            parameter.Add(new SqlParameter("@Email", register.email));
            parameter.Add(new SqlParameter("@Gender", register.gender));
            parameter.Add(new SqlParameter("@Skills", register.skills));
            parameter.Add(new SqlParameter("@DOB", register.dob));
            parameter.Add(new SqlParameter("@CreatedDate", register.createdDate));

                var result = await Task.Run(() => _dbContext.Database
               .ExecuteSqlRawAsync(@"exec SaveOrUpdateRegisters @ID, @Name, @Email, @Gender, @Skills, @DOB, @CreatedDate", parameter.ToArray()));

            return result;
        }
    }
}
