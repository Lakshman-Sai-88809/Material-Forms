﻿using System.ComponentModel.DataAnnotations;

namespace register.Model
{
    public class Register
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Required")]
        [MaxLength(50, ErrorMessage = "MaxLength")]
        public string? name { get; set; }

        [Required(ErrorMessage = "Required")]
        [MaxLength(350, ErrorMessage = "MaxLength")]
        public string? email { get; set; }

        [MaxLength(1, ErrorMessage = "MaxLength")]
        [RegularExpression("^[MFOmfo]$", ErrorMessage = "InValid")]
        public string? gender { get; set; }

        [Required(ErrorMessage = "Required")]
        [MaxLength(25, ErrorMessage = "MaxLength")]
        public string? skills { get; set; }

        [DataType(DataType.Date, ErrorMessage = "InValid")]
        public DateTime dob { get; set; } = DateTime.Now;

        public DateTime createdDate { get; set; } = DateTime.Now;


        public DateTime updatedDate { get; set; } = DateTime.Now;


    }
}
