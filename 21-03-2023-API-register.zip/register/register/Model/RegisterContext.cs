﻿using Microsoft.EntityFrameworkCore;

namespace register.Model
{
    public class RegisterContext : DbContext
    {
        public RegisterContext(DbContextOptions<RegisterContext> options) : base(options)
        {
        }
        public DbSet<Register> register { get; set; }
    }

}
