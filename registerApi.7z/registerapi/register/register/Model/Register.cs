﻿namespace register.Model
{
    public class Register
    {
        public int Id { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string address { get; set; }
        public DateTime dob { get; set; }
        public string skills { get; set; }
        public string gender { get; set; }

    }
}
