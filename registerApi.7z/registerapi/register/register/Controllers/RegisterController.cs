﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using register.Model;

namespace register.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RegisterController : ControllerBase
    {
        private readonly RegisterContext _RegisterContext;
        public RegisterController(RegisterContext registerContext)
        {
            this._RegisterContext = registerContext;
        }


        [HttpGet]
        public async Task<ActionResult<List<Register>>> GetRegisterList()
        {
            var response = await _RegisterContext.register.ToListAsync();
            return Ok(response);

        }
        [HttpGet("{id}")]
        public async Task<ActionResult> GetRegister(int id)
        {
            if (_RegisterContext.register == null)
            {
                return NotFound();
            }
            var response = await _RegisterContext.register.FirstOrDefaultAsync(m => m.Id == id);
            if (response == null)
            {
                return NotFound();
            }
            return Ok(response);

        }

        [HttpPost]
        public async Task<ActionResult<Register>> Post(Register register)
        {
            var response = _RegisterContext.register.AddAsync(register);
            await _RegisterContext.SaveChangesAsync();
            return Ok(response);
        }
        [HttpPut]
        public async Task<ActionResult> updateRegister([FromRoute] Guid Id, Register updateRegisterrequest)
        {
            var register = await _RegisterContext.register.FirstOrDefaultAsync();

            if (register != null)
            {
                _RegisterContext.register.Update(register);
            }

            //register.firstName = updateRegisterrequest.firstName;
            //register.lastName = updateRegisterrequest.lastName;
            //register.address = updateRegisterrequest.address;
            //register.dob = updateRegisterrequest.dob;
            //register.skills = updateRegisterrequest.skills;
            //register.gender = updateRegisterrequest.gender;

            await _RegisterContext.SaveChangesAsync();

            return Ok(register);

        }
        [HttpDelete]
        public async Task<ActionResult> DeleteRegister(int Id)
        {
            var register = await _RegisterContext.register.FindAsync(Id);
            if(register != null)
            {
                _RegisterContext.register.Remove(register);
                await _RegisterContext.SaveChangesAsync();
            }
             return Ok(register);
        }






    }
}





    






