import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { map } from 'rxjs/operators'
import { Register } from './shared/register';
import { Observable } from 'rxjs';



@Injectable({
  providedIn: 'root'
})
export class CRUDServicesService {

  constructor(private http: HttpClient) { }
  employeeurl: string = 'https://localhost:44317/api/Register/getRegistersList';
  listofemployee: Register[] = [];//for getting employee
  registerData=new Register();
  getRegisters(): Observable<Register[]> {
    return this.http.get<Register[]>(this.employeeurl);
  }
  saveEmployee(registerData: any) : Observable<Register>{
    const url = 'https://localhost:44317/api/Register/addregister'
    return this.http.post<Register>(url,registerData)
  }
  updateEmployee(){
    return this.http.put(`${this.employeeurl}/${this.registerData.id}`,this.registerData)
  }
  deleteEmployee(id:number){
    return this.http.delete(`${'https://localhost:44317/api/Register?registerId'}=${id}`)
  }
}


