import { Component, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { CRUDServicesService } from './crudservices.service';
import { Register } from './shared/register';
import { MatDialog } from '@angular/material/dialog';
import { AddOrUpdateRegisterComponent } from './AddOrUpdateRegister/AddOrUpdateRegister.component';
import { DeleteRegisterConfirmPageComponent } from './DeleteRegisterConfirmPage/DeleteRegisterConfirmPage.component';
import { MatTableDataSource } from '@angular/material/table';
import {MatPaginator } from '@angular/material/paginator';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  displayedColumns: string[] = ['action', 'name', 'email', 'gender', 'skills', 'dob', 'createdDate', 'updatedDate'];
  columnsToDisplay: string[] = this.displayedColumns.slice();
  registerData: Register[];
  viewRegistersData: Register[];
  expandedElement: Register | null;

  constructor(public crudservice: CRUDServicesService, public dialog: MatDialog) { }
  ngOnInit() {
    this.crudservice.getRegisters().subscribe(data => {
      this.registerData = data;
      console.log(this.registerData);
    })
  }

  viewRegisterData(id: number) {
    this.viewRegistersData = this.registerData.filter(x => x.id == id);
    this.viewRegistersData[0].readonly = true;
    console.log(this.viewRegistersData);
    const dialogRef = this.dialog.open(AddOrUpdateRegisterComponent, {
      width: '640px', disableClose: true, data: this.viewRegistersData
    });
  }

  deleteFormData(id: number) {
    const dialogRef = this.dialog.open(DeleteRegisterConfirmPageComponent, {
      width: '500px', disableClose: true, data: id
    });
  }
  addRegister() {
    const dialogRef = this.dialog.open(AddOrUpdateRegisterComponent, {
      width: '640px', disableClose: true
    });
  }

  editRegisterData(id: number) {
    this.viewRegistersData = this.registerData.filter(x => x.id == id);
    this.viewRegistersData[0].readonly = false;
    console.log(this.viewRegistersData);
    const dialogRef = this.dialog.open(AddOrUpdateRegisterComponent, {
      width: '640px', disableClose: true, data: this.viewRegistersData
    });
  }

}
