import { Component, Inject, Input, OnInit } from "@angular/core";
import { FormControl, FormGroup, Validators } from "@angular/forms";
import { MatDialog, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { CRUDServicesService } from "../crudservices.service";
import { Register } from "../shared/register";


@Component({
  selector: 'AddOrUpdateRegister',
  templateUrl: './AddOrUpdateRegister.component.html',
  styleUrls: ['./AddOrUpdateRegister.component.css']
})

export class AddOrUpdateRegisterComponent implements OnInit {
  @Input() registerData: Register[];
  skills: string[] = ['C#', 'Angular', '.Net', 'SQL'];
  inputData: Register;
  expandedElement: Register | null;
  showMsg: boolean;
  viewDataOnly: boolean;

  constructor(public crudservice: CRUDServicesService, public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  ngOnInit() {
    console.log(this.data);
    if (this.data != null) {
      this.inputData = this.data[0];
      this.viewDataOnly = this.inputData.readonly;
      if (this.viewDataOnly == true) {
        this.profileForm.disable();
      }
      this.profileForm.patchValue(this.data[0]);
    }
  }
  profileForm = new FormGroup({
    id: new FormControl(),
    name: new FormControl("", [Validators.required, Validators.pattern("^([a-zA-Z *% '.,-]+(^.)?[\s]*)$")]),
    email: new FormControl("", [Validators.required, Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$")]),
    dob: new FormControl("", [Validators.required]),
    gender: new FormControl("", [Validators.required]),
    skills: new FormControl("", [Validators.required]),
    createdDate: new FormControl(Date),
    updatedDate: new FormControl(Date),
  })

  saveForm() {
    if (this.inputData != null) {
      this.profileForm.controls["id"].patchValue(this.inputData.id);
      this.crudservice.saveEmployee(this.profileForm.getRawValue()).subscribe(data => {
        if (data != null) {
          this.dialog.closeAll();
          alert("Updated Register's Data Successfully");
          window.location.reload();
        }
        else {
          alert("Register data not updated");
        }
      })
    }
    else {
      if (this.profileForm.value != null) {
        var id = this.profileForm.controls['id'].value == null ? 0 : this.profileForm.controls['id'].value
        this.profileForm.controls['id'].patchValue(id);
        this.crudservice.saveEmployee(this.profileForm.getRawValue()).subscribe(data => {
          if (data != null) {
            this.dialog.closeAll();
            alert("Added Successfully");
            window.location.reload();
          }
          else {
            alert("Issue while saving the data");
          }
        })
      }
    }
  }

  close() {
    this.dialog.closeAll();
  }
  
  get f() {
    return this.profileForm.controls;
  }
}

