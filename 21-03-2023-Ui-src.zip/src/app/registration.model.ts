export class registration
{
    // Id:number;
    // userName: string;
    // emailId: string;
    // address: string;
    // gender: string='Male';
    // city: string;
    // state: string;
    // zipcode: number;
}