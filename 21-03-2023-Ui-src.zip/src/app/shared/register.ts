export class Register {
    id:number=0;
    actionIcons: number;
    name: string;
    email: string;
    gender: string;
    skills: string;
    dob: Date;
    createdDate:Date;
    updatedDate: Date;
    readonly: boolean;
}

