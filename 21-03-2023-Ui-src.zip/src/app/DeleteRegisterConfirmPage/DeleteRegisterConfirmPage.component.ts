import { Component, Inject, Input, OnInit } from "@angular/core";
import { MatDialog, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { CRUDServicesService } from "../crudservices.service";


@Component({
    selector: 'DeleteRegisterConfirmPage',
    templateUrl: './DeleteRegisterConfirmPage.component.html',
    styleUrls: ['./DeleteRegisterConfirmPage.component.css']
})

export class DeleteRegisterConfirmPageComponent {

registerId: number;

constructor(public dialog: MatDialog, public crudservice: CRUDServicesService, @Inject(MAT_DIALOG_DATA) public data: any) { }

close() {
    this.dialog.closeAll();
}

deleteRegisterData() {
        this.registerId = this.data
        this.crudservice.deleteEmployee(this.registerId).subscribe(res => {
            if (res != null && res > 0) {
                this.dialog.closeAll();
                alert("Deleted register data Successfully");
                window.location.reload();
            }
        });
}
}